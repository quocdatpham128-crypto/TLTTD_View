package com.example.tlttd_view

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.tlttd_view.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var currentStudent = Student(
        id = "22505120005",
        name = "Nguyen Van An",
        className = "DD2026",
        email = "anv@ute.udn.vn",
        gpa = 3.8
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Khởi tạo ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Gán dữ liệu ban đầu
        bindStudentData(currentStudent)

        // Cập nhật điểm GPA
        binding.btnUpdateGpa.setOnClickListener {
            updateGpaProcess()
        }
    }

    // 1. Scope function 'with'
    private fun bindStudentData(student: Student) {
        with(binding) {
            tvName.text = student.name
            tvStudentId.text = "MSSV: ${student.id} | Lớp: ${student.className}"
            tvGpaBadge.text = "${student.gpa} GPA (${student.gpa.toAcademicRanking()})"
            edtNewGpa.setText(student.gpa.toString())
        }
    }

    // 2. Scope functions 'let', 'run', 'also'
    private fun updateGpaProcess() {
        val inputStr = binding.edtNewGpa.trimmedText()

        inputStr.toDoubleOrNull()?.let { newGpa ->
            if (newGpa in 0.0..4.0) {
                currentStudent = currentStudent.copy(gpa = newGpa).also { updated ->
                    Log.d("STUDENT_LOG", "Đã cập nhật GPA cho ${updated.name}: ${updated.gpa}")
                }
                bindStudentData(currentStudent)
                toast("Cập nhật điểm thành công!")
            } else {
                showGpaError("Giá trị GPA phải nằm trong khoảng 0.0 - 4.0")
            }
        } ?: run {
            showGpaError("Vui lòng nhập định dạng số hợp lệ!")
        }
    }

    // 3. Scope function 'apply'
    private fun showGpaError(errorMessage: String) {
        binding.edtNewGpa.apply {
            error = errorMessage
            requestFocus()
        }
        toast(errorMessage)
    }
}