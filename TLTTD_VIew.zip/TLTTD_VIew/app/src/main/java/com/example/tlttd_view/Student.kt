package com.example.tlttd_view
data class Student(
    val id: String,
    val name: String,
    val className: String,
    val email: String,
    val gpa: Double
)
