package com.example.tlttd_view

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.tlttd_view.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    // Khai báo ViewBinding cơ bản theo yêu cầu
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.tvName.text = "Nguyen Van An"
        binding.tvStudentId.text = "MSSV: 22505120005 | Lớp: DD2026"
        binding.tvGpaBadge.text = "GPA: 3.8"
        binding.edtNewGpa.setText("3.8")

        binding.btnUpdateGpa.setOnClickListener {
            val inputGpa = binding.edtNewGpa.text.toString().trim()

            if (inputGpa.isNotEmpty()) {
                // Binding dữ liệu mới nhập vào TextView hiển thị điểm
                binding.tvGpaBadge.text = "GPA: $inputGpa"
                Toast.makeText(this, "Cập nhật thành công!", Toast.LENGTH_SHORT).show()
            } else {
                binding.edtNewGpa.error = "Vui lòng nhập GPA!"
            }
        }
    }
}